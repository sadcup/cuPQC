#ifdef COMMONDX_NAMESPACE_WRAPPER
} // namespace detail
} // namespace COMMONDX_NAMESPACE_WRAPPER
#endif
