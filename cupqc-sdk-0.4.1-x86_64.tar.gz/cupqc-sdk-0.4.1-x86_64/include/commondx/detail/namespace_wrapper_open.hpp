#ifdef COMMONDX_NAMESPACE_WRAPPER
namespace COMMONDX_NAMESPACE_WRAPPER {
namespace detail {
#endif
